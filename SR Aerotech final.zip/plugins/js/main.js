
jQuery(document).ready(function($) {
	//create the slider
	$('.cd-testimonials-wrapper').flexslider({
		selector: ".cd-testimonials > li",
		animation: "slide",
		controlNav: true,
		slideshow: false,
		smoothHeight: true,
		start: function() {
			$('.cd-testimonials').children('li').css({
				'opacity': 1,
				'position': 'relative'
			});
		}
	});
});

$(document).ready(function () {
    $('.owl-carousel').owlCarousel({
        loop: false,
        margin: 0,
        autoplay: true,
        autoplayTimeout: 2000,
        responsiveClass: true,
        responsive: {
            0: {
                items: 1,
                nav: false,
            },
            600: {
                items: 3,
                nav: false
            },
            1000: {
                items: 6,
                nav: false,
                loop: true,
                margin: 20
            }
        }
    })
  });



// gallery popup 

$(document).ready(function(){
    $('.image-popup-vertical-fit').magnificPopup({
      type: 'image',
      mainClass: 'mfp-with-zoom', 
      gallery:{
          enabled:true
        },
    
      zoom: {
        enabled: true,
    
        duration: 300, // duration of the effect, in milliseconds
        easing: 'ease-in-out', // CSS transition easing function
    
        opener: function(openerElement) {
    
          return openerElement.is('img') ? openerElement : openerElement.find('img');
      }
    }
    
    });
    
    });
    
  // gallery popup 

  
// scroll top 
$(window).scroll(function () {
  if ($(this).scrollTop() > 50) {
    $('.scrolltop:hidden').stop(true, true).fadeIn();
  } else {
    $('.scrolltop').stop(true, true).fadeOut();
  }
});
$(function () {
  $(".scroll").click(function () {
    $("html,body").animate({
      scrollTop: $(".thetop").offset().top
    }, "1000");
    return false
  })
})

// website visit count 


const countEl = document.getElementById('count');

updateVisitCount();

function updateVisitCount() {
	fetch('https://api.countapi.xyz/hit/offsetprinters')
	.then(res => res.json())
	.then(res => {
		countEl.innerHTML = res.value+1000;
	})
}

document.addEventListener('contextmenu', event => event.preventDefault());

  // video popup 

  $(document).ready(function(){
    $("#myModal").on("hidden.bs.modal",function(){
      $("#iframeYoutube").attr("src","");
    })
  });
  
  function changeVideo(vId){
    var iframe=document.getElementById("iframeYoutube");
    iframe.src="https://www.youtube.com/embed/"+vId;
  
    $("#myModal").modal("show");
  }